# MyReads Project
MyReads is a simple cataloging app that allows you to place books in one of three shelves or categories.

Currently Reading
Want to Read
Read
### Install
```
$npm install
```
### Run
```
$ npm start
```